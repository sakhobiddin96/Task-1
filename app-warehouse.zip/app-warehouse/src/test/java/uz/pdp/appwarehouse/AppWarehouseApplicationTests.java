package uz.pdp.appwarehouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppWarehouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
